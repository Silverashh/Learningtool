//index.js
const app = getApp()

Page({
  data: {
  },

    /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  },
  
  vocabulary: function(){
    wx.navigateTo({
      url: '/pages/vocabulary/vocabulary',
    })
  },

  calculation: function(){
    wx.navigateTo({
      url: '/pages/calculation/calculation',
    })
  },

  list: function(){
    wx.navigateTo({
      url: '/pages/list/list',
    })
  },

  concentration: function(){
    wx.navigateTo({
      url: '/pages/concentration/concentration',
    })
  },

  relax: function(){
    wx.navigateTo({
      url: '/pages/relax/relax',
    })
  }
})
