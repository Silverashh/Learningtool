// miniprogram/pages/concentration/concentration.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    multiArray: [['0','1','2','3','4','5','6','7','8'],['0','5','10','15','20','25','30','35','40','45','50','55']],
    multiIndex: [0, 0],//用于显示在picker选择器上
    hour: 0,
    minute: 0,
    second: 0,
    flag: false,
  },

  onShareAppMessage: function () {
  },
  onReady: function(){
    console.log("页面渲染完毕")
  },
  onUnload: function(){
    console.log("退出页面，数据清空")
    this.setData ({
      flag: false,
      multiIndex: [0, 0],
      hour: 0,
      minute: 0,
      second: 0
    })
  },
  change: function(e) {
    this.setData({
      multiIndex: e.detail.value,
      hour: this.data.multiArray[0][e.detail.value[0]],
      minute: this.data.multiArray[1][e.detail.value[1]]
    })
    console.log('picker发送选择改变，携带值为',this.data.multiIndex)
    console.log('设置的时间为',this.data.hour,'时',this.data.minute,'分')
  },

  columnchange: function(e) {
    console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
  },

  showdata: function() {
    if((this.data.hour==0)&&(this.data.minute==0))
    wx.showToast({
      title: '请先设置专注时长',
      icon: 'none',
      duration: 1500
    })
    else{
      this.setData ({
      flag: true
    })
    var that = this
    countDown(that)
    }
  },

  cancel: function() {
    var that = this;
    wx.showModal({
      title: "确认退出吗？",
      content: "退出后专注时长将清零，确认退出吗？",
      success (res) {
        if (res.confirm) {
          that.setData ({
            flag: false,
            multiIndex: [0, 0],
            hour: 0,
            minute: 0,
            second: 0
          })
        }}
    })
  }
},
)

function countDown(that) {
  if (!that.data.flag) that.setData ({
    hour: 0,
    minute: 0,
    second: 0
  })
  else {
    var hour = that.data.hour
    var minute = that.data.minute
    var second = that.data.second
    if (hour * 3600 + minute * 60 + second > 0) {
      setTimeout(function () {
        if(second == 0) {
         second = 59;
         if(minute > 0) minute--;
         else {
           minute = 59;
           hour--;
          }
        }
       else {
          second--;
       }
        that.setData ({
          hour: hour,
          minute: minute,
          second: second
       })
        countDown(that)
     }, 1000);
     }
    else wx.showModal({
      title: "恭喜你",
      content: "恭喜你完成本次的专注学习！",
      showCancel: false,
      confirmText: "我知道啦",
      success: function(){
        that.setData ({
          flag: false,
          multiIndex: [0, 0]
        })
      }
   })
  }
}