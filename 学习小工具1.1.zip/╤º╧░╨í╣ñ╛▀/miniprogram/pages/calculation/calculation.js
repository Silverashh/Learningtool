// miniprogram/pages/calculation/calculation.js
Page({
  data: {
    flag1: false,//控制加法
    flag2: false,//减法
    flag3: false,//乘法
    flag4: false,//除法
    practice: false,
    array: [0, 5, 10, 15, 20],
    value: 0,
    choice: 0, //表示选择的是哪种运算
    calarray: ['','加法','减法','乘法','除法'],
    signarray: ['','+','-','×','÷'],
    number: 0,
    a: 0,
    b: 0,
    c: 0,
    answer: null,
    correct: null,
    correctnum: 0,
    wrongnum: 0,
    progress: 0,
    pro: 0,
    input: false
  },

  /* 用户点击右上角分享 */
  onShareAppMessage: function () {  },

  add: function(){
    this.setData({
      flag1: true,
      choice: 1
    })
  },
  substract: function(){
    this.setData({
      flag2: true,
      choice: 2
    })
  },
  multiply: function(){
    this.setData({
      flag3: true,
      choice: 3
    })
  },
  divide: function(){
    this.setData({
      flag4: true,
      choice: 4
    })
  },
  cancel: function(){
    this.setData({
      choice: 0,
      value: 0,
      number: 0,
      flag1: false,
      flag2: false,
      flag3: false,
      flag4: false
    })
    console.log("所有的数据已经重置：",this.data.choice,this.data.flag1,this.data.flag2,this.data.flag3,this.data.flag4)
  },
  change: function(e){
    this.setData({
      value: e.detail.value
    })
  },
  enter: function(){
    if(this.data.value==0) wx.showToast({
      title: '请先设置题目数量',
      icon: 'none',
      duration: 1500
    })
    else {
      this.setData({
        number: this.data.array[this.data.value],
        practice: true
      })
      console.log("选择的题目数为：", this.data.number)
      var that = this;
      practice(that);
    }
  },
  input: function(e){
    this.setData({
      answer: e.detail.value,
      input: true
    })
    console.log("结果读取成功", this.data.answer)
    if(this.data.input) console.log("已经可以确认了")
    else console.log("还没有可以确认")
  },
  confirm: function(){
    if(this.data.input){
      var that = this
      decide(that)
      process(that)
      if(this.data.progress < this.data.number) {
      console.log("下面进行下一题的练习")
      practice(that)}
      else{
        console.log("练习已经全部完成")
        setTimeout(function () {
          wx.showToast({
            title: '练习完成！',
            icon: 'success',
            duration: 1500
          })},800)
        setTimeout(function () {
          that.setData({
          choice: 0,
          value: 0,
          number: 0,
          flag1: false,
          flag2: false,
          flag3: false,
          flag4: false,
          practice: false,
          correctnum: 0,
          wrongnum: 0,
          progress: 0,
          pro: 0,
          input: false
        })},1500)
      }
    }
      else wx.showToast({
        title: '请先输入答案',
        image: './警告.png',
        duration: 2000
      })
  },
  leave: function(){
    var that = this
    wx.showModal({
      title: "确认退出吗？",
      content: "坚持到底就是胜利！",
      cancelText: "继续",
      success (res) {
        if (res.confirm)  that.setData ({
          choice: 0,
          value: 0,
          number: 0,
          flag1: false,
          flag2: false,
          flag3: false,
          flag4: false,
          practice: false,
          correctnum: 0,
          wrongnum: 0,
          progress: 0,
          pro: 0,
          input: false
        })
        }
    })
  }
})

function practice(that) {
  var a, b, c
  switch(that.data.choice){
    case 1:
      a = random(0,100)
      b = random(0,100)
      c = a + b;
      break;
    case 2:
      a = random(0,100)
      b = random(0,100)
      c = a - b;
      break;
    case 3:
      a = random(0,30)
      b = random(0,10)
      c = a * b;
      break;
    case 4:
      a = Math.ceil(Math.random()*10);
      b = Math.ceil(Math.random()*10);
      a = a * b;
      c = a / b;
      break;
  }
  that.setData({
    a: a,
    b: b,
    c: c
  })
}

function decide(that){
  var c = that.data.c;
      if(c==that.data.answer) {
      var temp = that.data.correctnum + 1
      that.setData({
      correct: true,
      correctnum: temp
    })
    wx.showToast({
      title: '正确',
      icon: 'success',
      duration: 1000
    })
      console.log("答案正确", that.data.correct)}
      else {
      var temp = that.data.wrongnum + 1
      that.setData({
      correct: false,
      wrongnum: temp
     })
      wx.showToast({
        title: '错误',
        image: './错误.png',
        duration: 1000
      })
      console.log("答案错误", that.data.correct)}
}

function process(that) {
  var progress = that.data.progress
      progress++
      var pro = progress * 100 / that.data.number
      that.setData({
        answer: null,
        progress: progress,
        pro: pro,
        input: false
      })
  console.log("现在已经写了",progress,",进度是",pro,"%",",题目总数是",that.data.number)
}

function random(minNum,maxNum){ 
  switch(arguments.length){ 
      case 1: 
          return parseInt(Math.random()*minNum+1,10); 
      break; 
      case 2: 
          return parseInt(Math.random()*(maxNum-minNum+1)+minNum,10); 
      break; 
          default: 
              return 0; 
          break; 
  } 
} 