var sum = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

Page({

  data: {
    array: [[],['','草莓','苹果','西瓜','菠萝','橘子'],
    ['','郊外','电影院','公园','商场','酒吧','KTV'],
    ['','有才气的人','依赖你的人','优雅的人','善良的人','性情豪放的人'],
    ['','猫','马','大象','猴子','狗','狮子'],
    ['','游泳','喝冷饮','开空调'],
    ['','蛇','猪','老鼠','苍蝇'],
    ['','悬疑推理类','童话神话类','自然科学类','伦理道德类','战争灾难类'],
    ['','打火机','口红','记事本','纸巾','手机'],
    ['','火车','自行车','汽车','飞机','步行'],
    ['','紫色','黑色','蓝色','白色','黄色','红色'],
    ['','瑜伽','自行车','乒乓球','拳击','足球','蹦极'],
    ['','湖边','草原','海边','森林','城市'],
    ['','雪','风','雨','雾','雷电'],
    ['','七层','一层','二十三层','十八层','三十层'],
    ['','丽江','拉萨','昆明','西安','杭州','北京']],
    index: [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    result: ""
  },

  onShareAppMessage: function () {},

  question1: function(e) {
    var n = 1
    if(e.detail.value!=0){
      this.setData({
        'index[1]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[1]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=2;
    else if (e.detail.value==2) sum[n]=3;
    else if (e.detail.value==3) sum[n]=5;
    else if (e.detail.value==4) sum[n]=10;
    else if (e.detail.value==5) sum[n]=15;
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  question2: function(e) {
    var n = 2
    if(e.detail.value!=0){
      this.setData({
        'index[2]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[2]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=2;
    else if (e.detail.value==2) sum[n]=3;
    else if (e.detail.value==3) sum[n]=5;
    else if (e.detail.value==4) sum[n]=10;
    else if (e.detail.value==5) sum[n]=15;
    else if (e.detail.value==6) sum[n]=20;
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  question3: function(e) {
    var n = 3
    if(e.detail.value!=0){
      this.setData({
        'index[3]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[3]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=2;
    else if (e.detail.value==2) sum[n]=3;
    else if (e.detail.value==3) sum[n]=5;
    else if (e.detail.value==4) sum[n]=10;
    else if (e.detail.value==5) sum[n]=15;
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  question4: function(e) {
    var n = 4
    if(e.detail.value!=0){
      this.setData({
        'index[4]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[4]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=2;
    else if (e.detail.value==2) sum[n]=3;
    else if (e.detail.value==3) sum[n]=5;
    else if (e.detail.value==4) sum[n]=10;
    else if (e.detail.value==5) sum[n]=15;
    else if (e.detail.value==6) sum[n]=20;
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  question5: function(e) {
    var n = 5
    if(e.detail.value!=0){
      this.setData({
        'index[5]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[5]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=5;
    else if (e.detail.value==2) sum[n]=10;
    else if (e.detail.value==3) sum[n]=15;
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  question6: function(e) {
    var n = 6
    if(e.detail.value!=0){
      this.setData({
        'index[6]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[6]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=2;
    else if (e.detail.value==2) sum[n]=5;
    else if (e.detail.value==3) sum[n]=10;
    else if (e.detail.value==4) sum[n]=15;
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  question7: function(e) {
    var n = 7
    if(e.detail.value!=0){
      this.setData({
        'index[7]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[7]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=2;
    else if (e.detail.value==2) sum[n]=3;
    else if (e.detail.value==3) sum[n]=5;
    else if (e.detail.value==4) sum[n]=10;
    else if (e.detail.value==5) sum[n]=15;
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  question8: function(e) {
    var n = 8
    if(e.detail.value!=0){
      this.setData({
        'index[8]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[8]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=2;
    else if (e.detail.value==2) sum[n]=3;
    else if (e.detail.value==3) sum[n]=5;
    else if (e.detail.value==4) sum[n]=10;
    else if (e.detail.value==5) sum[n]=15
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  question9: function(e) {
    var n = 9
    if(e.detail.value!=0){
      this.setData({
        'index[9]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[9]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=2;
    else if (e.detail.value==2) sum[n]=3;
    else if (e.detail.value==3) sum[n]=5;
    else if (e.detail.value==4) sum[n]=10;
    else if (e.detail.value==5) sum[n]=15;
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  question10: function(e) {
    var n = 10
    if(e.detail.value!=0){
      this.setData({
        'index[10]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[10]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=2;
    else if (e.detail.value==2) sum[n]=3;
    else if (e.detail.value==3) sum[n]=5;
    else if (e.detail.value==4) sum[n]=8;
    else if (e.detail.value==5) sum[n]=12;
    else if (e.detail.value==6) sum[n]=15;
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  question11: function(e) {
    var n = 11
    if(e.detail.value!=0){
      this.setData({
        'index[11]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[11]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=2;
    else if (e.detail.value==2) sum[n]=3;
    else if (e.detail.value==3) sum[n]=5;
    else if (e.detail.value==4) sum[n]=8;
    else if (e.detail.value==5) sum[n]=10;
    else if (e.detail.value==6) sum[n]=15;
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  question12: function(e) {
    var n = 12
    if(e.detail.value!=0){
      this.setData({
        'index[12]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[12]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=2;
    else if (e.detail.value==2) sum[n]=3;
    else if (e.detail.value==3) sum[n]=5;
    else if (e.detail.value==4) sum[n]=10;
    else if (e.detail.value==5) sum[n]=15;
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  question13: function(e) {
    var n = 13
    if(e.detail.value!=0){
      this.setData({
        'index[13]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[13]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=2;
    else if (e.detail.value==2) sum[n]=3;
    else if (e.detail.value==3) sum[n]=5;
    else if (e.detail.value==4) sum[n]=10;
    else if (e.detail.value==5) sum[n]=15;
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  question14: function(e) {
    var n = 14
    if(e.detail.value!=0){
      this.setData({
        'index[14]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[14]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=2;
    else if (e.detail.value==2) sum[n]=3;
    else if (e.detail.value==3) sum[n]=5;
    else if (e.detail.value==4) sum[n]=10;
    else if (e.detail.value==5) sum[n]=15;
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  question15: function(e) {
    var n = 15
    if(e.detail.value!=0){
      this.setData({
        'index[15]': e.detail.value
      })}
    if(e.detail.value==0){
      this.setData({
        'index[15]': 0
      })}
    console.log('picker发生选择改变，携带值为', this.data.index[n])
    if (e.detail.value==1) sum[n]=1;
    else if (e.detail.value==2) sum[n]=3;
    else if (e.detail.value==3) sum[n]=5;
    else if (e.detail.value==4) sum[n]=8;
    else if (e.detail.value==5) sum[n]=10;
    else if (e.detail.value==6) sum[n]=15;
    else sum[n]=0
    console.log("该项得分为：", sum[n])
  },

  showdata: function() {
    var decide = decision()
    console.log(decide)
    if (!decide) {
      wx.showModal({
        title: '提示',
        showCancel: false,
        confirmText: '知道啦',
        content: '请先完成所有的题目噢！',
    })}
    else {
      var sum = 0
      for(var i = 1;i <= 15; i++){
        sum += sum[i]
      }
      if (sum>=180) {
       this.setData({
          result:"你的意志力强，头脑冷静，有较强的领导欲，事业心强，不达目的不罢休。外表和善，内心自傲，对有利于自己的人际关系比较看重，有时显得性格急噪，咄咄逼人，得理不饶 人，不利于自己时顽强抗争，不轻易认输。思维理性，对爱情和婚姻的看法很现实，对金钱的欲望一般。"
       })
     }
      else if (sum>=140 && sum<=179) {
        this.setData({
         result:"你聪明，性格活泼，人缘好，善于交朋友，心机较深。事业心强，渴望成功。思维较理性，崇尚爱情，但当爱情与婚姻发生冲突时会选择有利于自己的婚姻。金钱欲望强烈。"
        })
      }
      else if (sum>=100 && sum<=139) {
        this.setData({
         result:"你是个爱幻想的人，思维较感性，以是否与自己投缘为标准来选择朋友。性格显得较孤傲，有时较急噪，有时优柔寡断。事业心较强，喜欢有创造性的工作，不喜欢按常规办事。性格倔强，言语犀利，不善于妥协。崇尚浪漫的爱情，但想法往往不切合实际。金钱欲望一般。"
       })
     }
      else if (sum>=70 && sum<=99) {
        this.setData({
         result:"你好奇心强，喜欢冒险，人缘较好。事业心一般，对待工作，随遇而安，善于妥协。善于发现有趣的事情，但耐心较差，敢于冒险，但有时较胆小。渴望浪漫的爱情，但对婚姻的要求比较现实。不善理财。"
       })
      }
     else if (sum>=40 && sum<=69) {
        this.setData({
         result:"你性情温良，重友谊，性格塌实稳重，但有时也比较狡黠。事业心一般，对本职工作能认真对待，但对自己专业以外事物没有太大兴趣，喜欢有规律的工作和生活，不喜欢冒险，家庭观念强，比较善于理财。"
       })
     }
     else this.setData({
       result:"你的性格偏向于散漫，爱玩，富于幻想。聪明机灵，待人热情，爱交朋友，但对朋友没有严格的选择标准。事业心较差，更善于享受生活，意志力和耐心都较差，我行我素。有较好的异性缘，但对爱情不够坚持认真，容易妥协。没有财产观念。"
     })
  }}
})

function decision(){
  var a = true
  for(var i = 1; i<=15; i++){
    if(sum[i]==0) a = false
  }
  return a
}